package exercice1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Partie1 {

	Scanner scan;
	FileInputStream fis;
	String[] etiquette;

	public Partie1(File file) {
		try {
			scan = new Scanner(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	public String readLine() {
		return scan.next();
	}

	public int numBloc(String line) {
		System.out.println(line);
		String tab[] = line.split(":");
		String adresse = tab[0];
		int adr = Integer.parseInt(adresse);
		int num = adr / 32;
		return num;
	}
	
	public void all() {
		while(scan.hasNext()) { // Tant qu'il y a une ligne a lire
			String line = readLine();
			numBloc(line);
		}
	}

	public static void main(String[] args) {
		Partie1 part = new Partie1(new File("./file/matrice10.txt"));
		part.all();
	}

}
